<?php
/**
 * Admin Dashboard Controller
 */

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Request;
use PDO;

class AdminController extends BaseController {
    public function __construct() {
        Auth::requireStaff();
    }

    public function index(Request $request): void {
        $db = Database::getInstance();

        // Real Database Queries for Dashboard Summary Cards
        $totalOrders = (int)$db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $pendingOrders = (int)$db->query("SELECT COUNT(*) FROM orders WHERE order_status = 'pending'")->fetchColumn();
        $awaitingPayment = (int)$db->query("SELECT COUNT(*) FROM orders WHERE payment_status = 'awaiting_confirmation'")->fetchColumn();
        $processingOrders = (int)$db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('confirmed', 'processing')")->fetchColumn();
        $completedOrders = (int)$db->query("SELECT COUNT(*) FROM orders WHERE order_status = 'completed'")->fetchColumn();
        
        // Total Sales from verified or completed orders
        $totalSales = (float)$db->query("
            SELECT COALESCE(SUM(total_amount), 0) 
            FROM orders 
            WHERE payment_status = 'verified' OR order_status = 'completed'
        ")->fetchColumn();

        $totalCustomers = (int)$db->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
        $activeProducts = (int)$db->query("SELECT COUNT(*) FROM products WHERE status = 'active'")->fetchColumn();
        $lowStockProducts = (int)$db->query("SELECT COUNT(*) FROM products WHERE stock_quantity <= low_stock_threshold AND stock_quantity > 0 AND status = 'active'")->fetchColumn();
        $outOfStockProducts = (int)$db->query("SELECT COUNT(*) FROM products WHERE stock_quantity = 0 AND status = 'active'")->fetchColumn();

        // Recent 8 Orders
        $recentOrders = $db->query("
            SELECT id, order_number, customer_name, customer_phone, total_amount, payment_status, order_status, created_at
            FROM orders
            ORDER BY id DESC
            LIMIT 8
        ")->fetchAll();

        // Top 5 Best-Selling Products from Order Items
        $bestSellers = $db->query("
            SELECT oi.product_id, oi.product_name, oi.sku, SUM(oi.quantity) as total_sold, SUM(oi.line_total) as total_revenue
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            WHERE o.order_status NOT IN ('cancelled')
            GROUP BY oi.product_id, oi.product_name, oi.sku
            ORDER BY total_sold DESC
            LIMIT 5
        ")->fetchAll();

        $this->render('admin.dashboard', [
            'pageTitle' => 'Admin Dashboard - Pande Computers',
            'stats' => [
                'totalOrders' => $totalOrders,
                'pendingOrders' => $pendingOrders,
                'awaitingPayment' => $awaitingPayment,
                'processingOrders' => $processingOrders,
                'completedOrders' => $completedOrders,
                'totalSales' => $totalSales,
                'totalCustomers' => $totalCustomers,
                'activeProducts' => $activeProducts,
                'lowStockProducts' => $lowStockProducts,
                'outOfStockProducts' => $outOfStockProducts,
            ],
            'recentOrders' => $recentOrders,
            'bestSellers' => $bestSellers,
        ], 'admin');
    }
}
