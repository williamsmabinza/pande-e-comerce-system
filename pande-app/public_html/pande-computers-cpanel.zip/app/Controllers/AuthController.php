<?php
/**
 * Authentication Controller
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Session;
use App\Core\Validator;
use App\Models\User;

class AuthController extends BaseController {
    public function showLogin(Request $request): void {
        if (Auth::check()) {
            $this->redirect(Auth::isAdmin() ? APP_URL . '/admin' : APP_URL . '/customer/dashboard');
            return;
        }

        $this->render('auth.login', [
            'pageTitle' => 'Sign In - Pande Computers',
        ], 'auth');
    }

    public function login(Request $request): void {
        $validator = new Validator($request->all(), [
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            Session::flash('error', $validator->firstError());
            $this->redirect(APP_URL . '/login');
            return;
        }

        $email = $request->input('email');
        $password = $request->input('password');

        if (Auth::attempt($email, $password)) {
            Session::flash('success', 'Welcome back, ' . Auth::name() . '!');
            if (Auth::isAdmin() || Auth::isStaff()) {
                $this->redirect(APP_URL . '/admin');
            } else {
                $this->redirect(APP_URL . '/customer/dashboard');
            }
            return;
        }

        Session::flash('error', 'Invalid email address or password.');
        $this->redirect(APP_URL . '/login');
    }

    public function showRegister(Request $request): void {
        if (Auth::check()) {
            $this->redirect(APP_URL . '/customer/dashboard');
            return;
        }

        $this->render('auth.register', [
            'pageTitle' => 'Create Account - Pande Computers',
        ], 'auth');
    }

    public function register(Request $request): void {
        $validator = new Validator($request->all(), [
            'first_name' => 'required|min:2|max:50',
            'last_name' => 'required|min:2|max:50',
            'email' => 'required|email|max:100',
            'phone' => 'required|min:9|max:20',
            'password' => 'required|min:6',
            'password_confirmation' => 'required|matches:password',
        ]);

        if ($validator->fails()) {
            Session::flash('error', $validator->firstError());
            $this->redirect(APP_URL . '/register');
            return;
        }

        $email = strtolower(trim($request->input('email')));
        if (User::findByEmail($email)) {
            Session::flash('error', 'An account with this email address already exists.');
            $this->redirect(APP_URL . '/register');
            return;
        }

        try {
            $userId = User::createCustomer([
                'first_name' => $request->input('first_name'),
                'last_name' => $request->input('last_name'),
                'email' => $email,
                'phone' => $request->input('phone'),
                'password' => $request->input('password'),
            ]);

            Auth::attempt($email, $request->input('password'));
            Session::flash('success', 'Account registered successfully! Welcome to Pande Computers.');
            $this->redirect(APP_URL . '/customer/dashboard');

        } catch (\Throwable $e) {
            Session::flash('error', 'Registration error: ' . $e->getMessage());
            $this->redirect(APP_URL . '/register');
        }
    }

    public function logout(Request $request): void {
        Auth::logout();
        Session::flash('info', 'You have been logged out.');
        $this->redirect(APP_URL . '/');
    }

    public function forgotPassword(Request $request): void {
        $this->render('auth.forgot_password', [
            'pageTitle' => 'Forgot Password - Pande Computers',
        ], 'auth');
    }
}
