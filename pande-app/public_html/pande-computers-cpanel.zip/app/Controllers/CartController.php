<?php
/**
 * Cart Controller
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Session;
use App\Models\Cart;

class CartController extends BaseController {
    public function index(Request $request): void {
        $items = Cart::getItems();
        $totals = Cart::getTotals();

        $this->render('cart.index', [
            'pageTitle' => 'Shopping Cart - Pande Computers',
            'cartItems' => $items,
            'totals' => $totals,
        ]);
    }

    public function add(Request $request): void {
        $productId = (int)$request->input('product_id');
        $quantity = max(1, (int)$request->input('quantity', 1));
        $product = \App\Models\Product::find($productId);

        $added = Cart::add($productId, $quantity);

        if ($request->isAjax()) {
            if ($added) {
                $totals = Cart::getTotals();
                $images = \App\Models\Product::getImages($productId);
                $imgPath = !empty($images) ? $images[0]['image_path'] : 'assets/images/products/laptop.svg';

                $this->json([
                    'success' => true,
                    'count' => $totals['count'],
                    'subtotal' => formatTZS($totals['subtotal']),
                    'product_name' => $product['name'] ?? 'Electronics Item',
                    'product_price' => formatTZS($product['price'] ?? 0),
                    'product_image' => asset($imgPath),
                    'message' => 'Item added to shopping cart!'
                ]);
            } else {
                $this->json(['success' => false, 'message' => 'Product is currently out of stock or unavailable.'], 400);
            }
            return;
        }

        if ($added) {
            Session::flash('success', 'Product added to your cart.');
        } else {
            Session::flash('error', 'Sorry, this product is currently out of stock.');
        }

        $this->redirect($_SERVER['HTTP_REFERER'] ?? (APP_URL . '/cart'));
    }

    public function update(Request $request): void {
        $productId = (int)$request->input('product_id');
        $quantity = (int)$request->input('quantity');

        Cart::updateQuantity($productId, $quantity);
        Session::flash('success', 'Cart updated successfully.');
        $this->redirect(APP_URL . '/cart');
    }

    public function remove(Request $request): void {
        $productId = (int)$request->input('product_id');
        Cart::remove($productId);
        Session::flash('success', 'Item removed from your cart.');
        $this->redirect(APP_URL . '/cart');
    }

    public function clear(Request $request): void {
        Cart::clear();
        Session::flash('info', 'Your cart has been cleared.');
        $this->redirect(APP_URL . '/cart');
    }
}
