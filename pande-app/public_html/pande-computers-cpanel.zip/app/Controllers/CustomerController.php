<?php
/**
 * Customer Account & Portal Controller
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Order;
use App\Models\User;

class CustomerController extends BaseController {
    public function __construct() {
        Auth::requireAuth();
    }

    public function dashboard(Request $request): void {
        $userId = (int)Auth::id();
        $orders = Order::getCustomerOrders($userId);
        $user = Auth::user();
        $addresses = User::getAddresses($userId);

        $this->render('customer.dashboard', [
            'pageTitle' => 'My Account - Pande Computers',
            'user' => $user,
            'orders' => array_slice($orders, 0, 5),
            'totalOrders' => count($orders),
            'addresses' => $addresses,
        ]);
    }

    public function orders(Request $request): void {
        $userId = (int)Auth::id();
        $orders = Order::getCustomerOrders($userId);

        $this->render('customer.orders', [
            'pageTitle' => 'My Order History - Pande Computers',
            'orders' => $orders,
        ]);
    }

    public function orderDetail(Request $request, array $params): void {
        $orderNumber = $params['number'] ?? '';
        $order = Order::findByNumber($orderNumber);

        if (!$order) {
            Session::flash('error', 'Order not found.');
            $this->redirect(APP_URL . '/customer/orders');
            return;
        }

        // STRICT SECURITY: Ownership verification
        if ((int)$order['user_id'] !== (int)Auth::id() && !Auth::isAdmin()) {
            Response::setStatusCode(403);
            Session::flash('error', 'Unauthorized access to order.');
            $this->redirect(APP_URL . '/customer/orders');
            return;
        }

        $this->render('customer.order_detail', [
            'pageTitle' => "Order #{$order['order_number']} - Pande Computers",
            'order' => $order,
        ]);
    }

    public function profile(Request $request): void {
        $user = Auth::user();

        if ($request->isPost()) {
            $validator = new Validator($request->all(), [
                'first_name' => 'required|min:2|max:50',
                'last_name' => 'required|min:2|max:50',
                'phone' => 'required|min:9|max:20',
            ]);

            if ($validator->fails()) {
                Session::flash('error', $validator->firstError());
                $this->redirect(APP_URL . '/customer/profile');
                return;
            }

            $db = \App\Core\Database::getInstance();
            $stmt = $db->prepare("UPDATE users SET first_name = :fn, last_name = :ln, phone = :phone WHERE id = :id");
            $stmt->execute([
                'fn' => $request->input('first_name'),
                'ln' => $request->input('last_name'),
                'phone' => $request->input('phone'),
                'id' => Auth::id()
            ]);

            Session::flash('success', 'Profile updated successfully.');
            $this->redirect(APP_URL . '/customer/profile');
            return;
        }

        $this->render('customer.profile', [
            'pageTitle' => 'Edit Profile - Pande Computers',
            'user' => $user,
        ]);
    }

    public function addresses(Request $request): void {
        $userId = (int)Auth::id();

        if ($request->isPost()) {
            $validator = new Validator($request->all(), [
                'recipient_name' => 'required|min:3|max:100',
                'phone' => 'required|min:9|max:20',
                'street_address' => 'required|min:5|max:255',
                'district' => 'required|min:2|max:100',
            ]);

            if ($validator->fails()) {
                Session::flash('error', $validator->firstError());
                $this->redirect(APP_URL . '/customer/addresses');
                return;
            }

            User::addAddress($userId, [
                'recipient_name' => $request->input('recipient_name'),
                'phone' => $request->input('phone'),
                'street_address' => $request->input('street_address'),
                'region_city' => $request->input('region_city', 'Dar es Salaam'),
                'district' => $request->input('district'),
                'landmark' => $request->input('landmark'),
                'is_default' => $request->input('is_default') ? 1 : 0,
            ]);

            Session::flash('success', 'Address added successfully.');
            $this->redirect(APP_URL . '/customer/addresses');
            return;
        }

        $addresses = User::getAddresses($userId);

        $this->render('customer.addresses', [
            'pageTitle' => 'Manage Addresses - Pande Computers',
            'addresses' => $addresses,
        ]);
    }
}
