<?php
/**
 * User Model
 */

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class User extends BaseModel {
    protected static string $table = 'users';

    public static function createCustomer(array $data): int {
        $db = static::db();
        $stmt = $db->prepare("
            INSERT INTO users (role, first_name, last_name, email, phone, password_hash, status)
            VALUES ('customer', :first_name, :last_name, :email, :phone, :password_hash, 'active')
        ");

        $stmt->execute([
            'first_name' => trim($data['first_name']),
            'last_name' => trim($data['last_name']),
            'email' => strtolower(trim($data['email'])),
            'phone' => trim($data['phone']),
            'password_hash' => password_hash($data['password'], PASSWORD_BCRYPT),
        ]);

        return (int)$db->lastInsertId();
    }

    public static function findByEmail(string $email): ?array {
        $db = static::db();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => strtolower(trim($email))]);
        return $stmt->fetch() ?: null;
    }

    public static function getAddresses(int $userId): array {
        $db = static::db();
        $stmt = $db->prepare("SELECT * FROM user_addresses WHERE user_id = :uid ORDER BY is_default DESC, id DESC");
        $stmt->execute(['uid' => $userId]);
        return $stmt->fetchAll();
    }

    public static function addAddress(int $userId, array $data): int {
        $db = static::db();
        if (!empty($data['is_default'])) {
            $reset = $db->prepare("UPDATE user_addresses SET is_default = 0 WHERE user_id = :uid");
            $reset->execute(['uid' => $userId]);
        }

        $stmt = $db->prepare("
            INSERT INTO user_addresses (user_id, recipient_name, phone, street_address, region_city, district, landmark, is_default)
            VALUES (:uid, :name, :phone, :address, :city, :district, :landmark, :is_default)
        ");

        $stmt->execute([
            'uid' => $userId,
            'name' => $data['recipient_name'],
            'phone' => $data['phone'],
            'address' => $data['street_address'],
            'city' => $data['region_city'] ?? 'Dar es Salaam',
            'district' => $data['district'] ?? 'Ilala',
            'landmark' => $data['landmark'] ?? null,
            'is_default' => !empty($data['is_default']) ? 1 : 0
        ]);

        return (int)$db->lastInsertId();
    }
}
