<div class="container-fluid">
    <!-- Top Action Row -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-dark mb-1">Executive Dashboard</h2>
            <p class="text-muted small mb-0">Real-time retail sales and inventory metrics &bull; Kariakoo, Dar es Salaam</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= APP_URL ?>/admin/products/create" class="btn btn-primary fw-semibold">
                <i class="bi bi-plus-circle me-1"></i> Add Product
            </a>
            <a href="<?= APP_URL ?>/admin/orders" class="btn btn-outline-dark fw-semibold">
                <i class="bi bi-receipt me-1"></i> Manage Orders
            </a>
        </div>
    </div>

    <!-- Summary KPI Cards -->
    <div class="row g-3 mb-4">
        <!-- Total Sales Revenue -->
        <div class="col-xl-3 col-sm-6">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100 border-start border-4 border-success">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Verified Sales</span>
                        <h3 class="fw-black text-dark mb-0 mt-1"><?= formatTZS($stats['totalSales']) ?></h3>
                        <span class="text-success small"><i class="bi bi-check2-all"></i> Verified Orders</span>
                    </div>
                    <div class="p-3 bg-success-subtle text-success rounded-circle fs-3">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Orders -->
        <div class="col-xl-3 col-sm-6">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100 border-start border-4 border-primary">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Total Orders</span>
                        <h3 class="fw-black text-dark mb-0 mt-1"><?= $stats['totalOrders'] ?></h3>
                        <span class="text-primary small"><?= $stats['completedOrders'] ?> Completed</span>
                    </div>
                    <div class="p-3 bg-primary-subtle text-primary rounded-circle fs-3">
                        <i class="bi bi-receipt"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Awaiting Payment Confirmation -->
        <div class="col-xl-3 col-sm-6">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100 border-start border-4 border-warning">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Awaiting Payment</span>
                        <h3 class="fw-black text-dark mb-0 mt-1"><?= $stats['awaitingPayment'] ?></h3>
                        <span class="text-warning small"><i class="bi bi-whatsapp"></i> WhatsApp Follow-up</span>
                    </div>
                    <div class="p-3 bg-warning-subtle text-warning rounded-circle fs-3">
                        <i class="bi bi-clock-history"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Low Stock / Out of Stock Alert -->
        <div class="col-xl-3 col-sm-6">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white h-100 border-start border-4 border-danger">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <span class="text-muted small fw-semibold text-uppercase">Inventory Alerts</span>
                        <h3 class="fw-black text-danger mb-0 mt-1"><?= $stats['lowStockProducts'] + $stats['outOfStockProducts'] ?></h3>
                        <span class="text-danger small"><?= $stats['outOfStockProducts'] ?> Out of Stock</span>
                    </div>
                    <div class="p-3 bg-danger-subtle text-danger rounded-circle fs-3">
                        <i class="bi bi-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Active Products & Customers Mini Row -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary-subtle text-primary p-2 rounded"><i class="bi bi-laptop fs-4"></i></div>
                    <div>
                        <div class="small text-muted">Active Products</div>
                        <h5 class="fw-bold mb-0"><?= $stats['activeProducts'] ?> items</h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-info-subtle text-info p-2 rounded"><i class="bi bi-people fs-4"></i></div>
                    <div>
                        <div class="small text-muted">Registered Customers</div>
                        <h5 class="fw-bold mb-0"><?= $stats['totalCustomers'] ?> clients</h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-success-subtle text-success p-2 rounded"><i class="bi bi-whatsapp fs-4"></i></div>
                    <div>
                        <div class="small text-muted">WhatsApp Line</div>
                        <h5 class="fw-bold mb-0">+255 787 311 342</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tables Row: Recent Orders & Best Sellers -->
    <div class="row g-4">
        <!-- Recent Orders -->
        <div class="col-xl-8">
            <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0 text-dark">Recent Customer Orders</h5>
                    <a href="<?= APP_URL ?>/admin/orders" class="small fw-semibold text-primary text-decoration-none">View All &rarr;</a>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light small">
                            <tr>
                                <th class="ps-3">Order Number</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Payment</th>
                                <th>Status</th>
                                <th class="pe-3 text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentOrders)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">No orders found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recentOrders as $ro): ?>
                                    <tr>
                                        <td class="ps-3 fw-bold font-monospace text-primary">
                                            <a href="<?= APP_URL ?>/admin/orders/detail/<?= $ro['id'] ?>" class="text-decoration-none">
                                                <?= e($ro['order_number']) ?>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-dark"><?= e($ro['customer_name']) ?></div>
                                            <div class="small text-muted"><?= e($ro['customer_phone']) ?></div>
                                        </td>
                                        <td class="fw-bold"><?= formatTZS($ro['total_amount']) ?></td>
                                        <td>
                                            <?php if ($ro['payment_status'] === 'verified'): ?>
                                                <span class="badge bg-success">Verified</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Awaiting</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary text-uppercase"><?= e($ro['order_status']) ?></span>
                                        </td>
                                        <td class="pe-3 text-end">
                                            <a href="<?= APP_URL ?>/admin/orders/detail/<?= $ro['id'] ?>" class="btn btn-outline-dark btn-sm">
                                                Manage
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Best Sellers -->
        <div class="col-xl-4">
            <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                <div class="card-header bg-white border-bottom p-3">
                    <h5 class="fw-bold mb-0 text-dark">Top Best-Selling Items</h5>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($bestSellers)): ?>
                        <div class="p-4 text-center text-muted small">No completed sales recorded yet.</div>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($bestSellers as $bs): ?>
                                <li class="list-group-item p-3 d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="fw-bold mb-0 text-dark small"><?= e($bs['product_name']) ?></h6>
                                        <span class="small text-muted">SKU: <?= e($bs['sku']) ?> &bull; Sold: <strong><?= $bs['total_sold'] ?></strong></span>
                                    </div>
                                    <span class="badge bg-success-subtle text-success fw-bold"><?= formatTZS($bs['total_revenue']) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
