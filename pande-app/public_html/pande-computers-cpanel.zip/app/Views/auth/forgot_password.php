<h4 class="fw-bold text-dark text-center mb-1">Forgot Password</h4>
<p class="text-muted small text-center mb-4">Enter your registered email address to receive recovery instructions</p>

<form action="<?= APP_URL ?>/forgot-password" method="POST">
    <?= $csrfInput ?>

    <div class="mb-3">
        <label class="form-label fw-semibold small">Email Address</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope text-secondary"></i></span>
            <input type="email" name="email" class="form-control" placeholder="name@example.com" required autofocus>
        </div>
    </div>

    <button type="submit" class="btn btn-primary w-100 fw-bold py-2 mb-3 shadow-sm">
        Send Password Reset Link
    </button>
</form>

<div class="alert alert-info small mb-3">
    <i class="bi bi-info-circle me-1"></i> You can also contact our Kariakoo support team on WhatsApp at <strong>+255 787 311 342</strong> for immediate account assistance.
</div>

<div class="text-center small border-top pt-3">
    <a href="<?= APP_URL ?>/login" class="text-primary text-decoration-none fw-semibold">&larr; Back to Sign In</a>
</div>
