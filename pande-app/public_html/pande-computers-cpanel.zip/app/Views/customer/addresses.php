<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h2 fw-bold text-dark mb-1">Saved Addresses</h1>
            <p class="text-muted mb-0">Manage delivery locations for quick checkout</p>
        </div>
    </div>

    <div class="row g-4">
        <!-- Existing Addresses -->
        <div class="col-lg-7">
            <div class="row g-3">
                <?php if (empty($addresses)): ?>
                    <div class="col-12">
                        <div class="card p-4 text-center text-muted border-0 shadow-sm">
                            No saved addresses found. Add your first address using the form.
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($addresses as $addr): ?>
                        <div class="col-12">
                            <div class="card p-3 border-0 shadow-sm rounded-3">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <h6 class="fw-bold mb-0 text-dark"><?= e($addr['recipient_name']) ?></h6>
                                    <?php if ($addr['is_default']): ?>
                                        <span class="badge bg-primary">Default</span>
                                    <?php endif; ?>
                                </div>
                                <div class="small text-secondary mb-1">
                                    <i class="bi bi-geo-alt me-1"></i> <?= e($addr['street_address']) ?>, <?= e($addr['district']) ?>, <?= e($addr['region_city']) ?>
                                </div>
                                <?php if (!empty($addr['landmark'])): ?>
                                    <div class="small text-muted mb-1">Near: <?= e($addr['landmark']) ?></div>
                                <?php endif; ?>
                                <div class="small text-muted">
                                    <i class="bi bi-telephone me-1"></i> <?= e($addr['phone']) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Add Address Form -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-3 p-4">
                <h5 class="fw-bold mb-3 text-dark">Add New Address</h5>
                <form action="<?= APP_URL ?>/customer/addresses" method="POST">
                    <?= $csrfInput ?>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Recipient Full Name</label>
                        <input type="text" name="recipient_name" class="form-control form-control-sm" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Contact Phone</label>
                        <input type="text" name="phone" class="form-control form-control-sm" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Street Address / House No.</label>
                        <input type="text" name="street_address" class="form-control form-control-sm" required>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">District</label>
                            <input type="text" name="district" class="form-control form-control-sm" placeholder="Ilala / Kinondoni" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">City</label>
                            <input type="text" name="region_city" class="form-control form-control-sm" value="Dar es Salaam" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Landmark (Optional)</label>
                        <input type="text" name="landmark" class="form-control form-control-sm" placeholder="Opposite church, near roundabout">
                    </div>

                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="is_default" value="1" id="is_default">
                        <label class="form-check-label small" for="is_default">Set as default delivery address</label>
                    </div>

                    <button type="submit" class="btn btn-primary btn-sm w-100 fw-bold py-2">
                        Save Address
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
