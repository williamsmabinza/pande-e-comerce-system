<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h2 fw-bold text-dark mb-1">Customer Dashboard</h1>
            <p class="text-muted mb-0">Welcome back, <strong><?= e($user['first_name'] . ' ' . $user['last_name']) ?></strong>!</p>
        </div>
        <div>
            <a href="<?= APP_URL ?>/shop" class="btn btn-primary fw-semibold"><i class="bi bi-cart-plus me-1"></i> New Purchase</a>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-circle bg-primary-subtle text-primary p-3 fs-3">
                        <i class="bi bi-box-seam"></i>
                    </div>
                    <div>
                        <span class="text-muted small">Total Orders</span>
                        <h3 class="fw-bold mb-0 text-dark"><?= $totalOrders ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-circle bg-success-subtle text-success p-3 fs-3">
                        <i class="bi bi-whatsapp"></i>
                    </div>
                    <div>
                        <span class="text-muted small">WhatsApp Support</span>
                        <h6 class="fw-bold mb-0 text-dark">+255 787 311 342</h6>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 p-3 bg-white">
                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-circle bg-info-subtle text-info p-3 fs-3">
                        <i class="bi bi-geo-alt"></i>
                    </div>
                    <div>
                        <span class="text-muted small">Saved Addresses</span>
                        <h3 class="fw-bold mb-0 text-dark"><?= count($addresses) ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0 text-dark">Recent Orders</h5>
            <a href="<?= APP_URL ?>/customer/orders" class="small fw-semibold text-primary text-decoration-none">View All Orders &rarr;</a>
        </div>
        <div class="card-body p-0">
            <?php if (empty($orders)): ?>
                <div class="p-4 text-center text-muted">
                    <p class="mb-2">You haven't placed any orders yet.</p>
                    <a href="<?= APP_URL ?>/shop" class="btn btn-outline-primary btn-sm">Start Shopping</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">Order Number</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th class="text-end pe-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $ord): ?>
                                <tr>
                                    <td class="ps-3 fw-bold font-monospace text-primary">
                                        <?= e($ord['order_number']) ?>
                                    </td>
                                    <td class="small text-muted"><?= date('M d, Y', strtotime($ord['created_at'])) ?></td>
                                    <td class="fw-bold"><?= formatTZS($ord['total_amount']) ?></td>
                                    <td>
                                        <span class="badge bg-secondary text-uppercase"><?= e($ord['order_status']) ?></span>
                                    </td>
                                    <td>
                                        <?php if ($ord['payment_status'] === 'verified'): ?>
                                            <span class="badge bg-success">Verified</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Awaiting</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-3">
                                        <a href="<?= APP_URL ?>/customer/order/<?= e($ord['order_number']) ?>" class="btn btn-sm btn-outline-dark">
                                            View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
