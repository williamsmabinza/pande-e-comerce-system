<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <h1 class="h2 fw-bold text-dark mb-4">Edit Profile</h1>

            <div class="card border-0 shadow-sm rounded-3 p-4">
                <form action="<?= APP_URL ?>/customer/profile" method="POST">
                    <?= $csrfInput ?>

                    <div class="row g-3 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold small">First Name</label>
                            <input type="text" name="first_name" class="form-control" value="<?= e($user['first_name']) ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold small">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?= e($user['last_name']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Email Address</label>
                        <input type="email" class="form-control bg-light" value="<?= e($user['email']) ?>" readonly>
                        <div class="form-text">Email address cannot be changed.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Phone (WhatsApp)</label>
                        <input type="text" name="phone" class="form-control" value="<?= e($user['phone']) ?>" required>
                    </div>

                    <button type="submit" class="btn btn-primary fw-bold w-100 py-2">
                        Save Changes
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
