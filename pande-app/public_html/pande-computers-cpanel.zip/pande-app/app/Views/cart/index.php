<div class="container py-4">
    <h1 class="h2 fw-bold text-dark mb-4"><i class="bi bi-cart3 text-primary me-2"></i> Shopping Cart</h1>

    <?php if (empty($cartItems)): ?>
        <div class="card border-0 shadow-sm rounded-3 p-5 text-center my-4">
            <i class="bi bi-cart-x text-muted mb-3" style="font-size: 4rem;"></i>
            <h4 class="fw-bold text-dark">Your Shopping Cart is Empty</h4>
            <p class="text-muted mb-4">You have not added any technology items to your cart yet.</p>
            <div>
                <a href="<?= APP_URL ?>/shop" class="btn btn-primary btn-lg px-4 fw-bold">
                    <i class="bi bi-laptop me-2"></i> Start Shopping Now
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <!-- Items Table -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm rounded-3 overflow-hidden mb-3">
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4" style="width: 45%;">Product</th>
                                    <th>Unit Price</th>
                                    <th style="width: 130px;">Quantity</th>
                                    <th>Line Total</th>
                                    <th class="pe-4 text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cartItems as $productId => $item): ?>
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center gap-3">
                                                <div class="bg-light p-2 rounded text-center" style="width: 50px; height: 50px;">
                                                    <i class="bi bi-laptop text-primary fs-3"></i>
                                                </div>
                                                <div>
                                                    <a href="<?= APP_URL ?>/product/<?= e($item['slug']) ?>" class="fw-bold text-dark text-decoration-none hover-primary">
                                                        <?= e($item['name']) ?>
                                                    </a>
                                                    <div class="small text-muted">SKU: <?= e($item['sku']) ?> &bull; <?= e($item['brand']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="fw-semibold text-secondary">
                                            <?= formatTZS($item['price']) ?>
                                        </td>
                                        <td>
                                            <form action="<?= APP_URL ?>/cart/update" method="POST" class="d-flex align-items-center">
                                                <?= $csrfInput ?>
                                                <input type="hidden" name="product_id" value="<?= (int)$productId ?>">
                                                <input type="number" name="quantity" class="form-control form-control-sm text-center" value="<?= (int)$item['quantity'] ?>" min="1" max="<?= (int)$item['max_stock'] ?>" onchange="this.form.submit()">
                                            </form>
                                        </td>
                                        <td class="fw-bold text-primary">
                                            <?= formatTZS($item['line_total']) ?>
                                        </td>
                                        <td class="pe-4 text-end">
                                            <form action="<?= APP_URL ?>/cart/remove" method="POST" class="d-inline">
                                                <?= $csrfInput ?>
                                                <input type="hidden" name="product_id" value="<?= (int)$productId ?>">
                                                <button type="submit" class="btn btn-outline-danger btn-sm border-0" title="Remove item">
                                                    <i class="bi bi-trash3-fill"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center">
                    <a href="<?= APP_URL ?>/shop" class="btn btn-outline-dark fw-semibold">
                        <i class="bi bi-arrow-left me-1"></i> Continue Shopping
                    </a>
                    <form action="<?= APP_URL ?>/cart/clear" method="POST">
                        <?= $csrfInput ?>
                        <button type="submit" class="btn btn-outline-secondary btn-sm" onclick="return confirm('Are you sure you want to clear your shopping cart?')">
                            <i class="bi bi-x-circle me-1"></i> Clear Cart
                        </button>
                    </form>
                </div>
            </div>

            <!-- Summary Card -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-3 p-4">
                    <h5 class="fw-bold text-dark mb-3">Order Summary</h5>

                    <!-- Free Delivery Progress -->
                    <?php if ($totals['amount_to_free_delivery'] > 0): ?>
                        <div class="alert alert-warning small py-2 mb-3">
                            <i class="bi bi-truck me-1"></i> Add <strong><?= formatTZS($totals['amount_to_free_delivery']) ?></strong> more to qualify for <strong>FREE DELIVERY</strong> in Dar es Salaam!
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success small py-2 mb-3">
                            <i class="bi bi-check-circle-fill me-1"></i> You qualify for <strong>FREE DELIVERY</strong> in Dar es Salaam!
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal (<?= $totals['count'] ?> items)</span>
                        <span class="fw-semibold text-dark"><?= formatTZS($totals['subtotal']) ?></span>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Delivery (Dar es Salaam)</span>
                        <span class="fw-semibold text-dark">
                            <?= $totals['delivery_fee'] > 0 ? formatTZS($totals['delivery_fee']) : '<span class="text-success">FREE</span>' ?>
                        </span>
                    </div>

                    <hr class="my-3">

                    <div class="d-flex justify-content-between align-items-baseline mb-4">
                        <span class="fw-bold fs-5 text-dark">Estimated Total</span>
                        <span class="fw-black fs-4 text-primary"><?= formatTZS($totals['total']) ?></span>
                    </div>

                    <a href="<?= APP_URL ?>/checkout" class="btn btn-primary btn-lg w-100 fw-bold mb-3 shadow">
                        Proceed to Checkout <i class="bi bi-arrow-right ms-2"></i>
                    </a>

                    <div class="small text-muted text-center">
                        <i class="bi bi-shield-lock me-1"></i> Safe & verified checkout via official WhatsApp line.
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
