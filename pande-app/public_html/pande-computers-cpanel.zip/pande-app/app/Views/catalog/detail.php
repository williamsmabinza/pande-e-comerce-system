<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/" class="text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/shop" class="text-decoration-none">Shop</a></li>
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/category/<?= e($product['category_slug']) ?>" class="text-decoration-none"><?= e($product['category_name']) ?></a></li>
            <li class="breadcrumb-item active text-truncate" style="max-width: 300px;" aria-current="page"><?= e($product['name']) ?></li>
        </ol>
    </nav>

    <!-- Product Main Info Card -->
    <div class="card border-0 shadow-sm rounded-3 p-4 mb-5">
        <div class="row g-5">
            <!-- Product Gallery Column -->
            <div class="col-lg-6">
                <div class="bg-light rounded-4 p-5 text-center border position-relative d-flex align-items-center justify-content-center" style="min-height: 380px;">
                    <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                        <?php $discount = round((($product['compare_at_price'] - $product['price']) / $product['compare_at_price']) * 100); ?>
                        <span class="badge bg-danger position-absolute top-0 start-0 m-3 px-3 py-2 fs-6 shadow-sm">-<?= $discount ?>% OFF</span>
                    <?php endif; ?>
                    <span class="badge bg-navy text-white position-absolute top-0 end-0 m-3 px-3 py-2 fs-6 shadow-sm"><?= e($product['brand']) ?></span>

                    <i class="bi bi-laptop text-primary opacity-75" style="font-size: 8rem;"></i>
                </div>
                <div class="mt-3 text-center text-muted small">
                    <i class="bi bi-info-circle me-1"></i> Genuine manufacturer retail product available at our Kariakoo store.
                </div>
            </div>

            <!-- Product Details Column -->
            <div class="col-lg-6 d-flex flex-column">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle"><?= e($product['brand']) ?></span>
                    <span class="text-muted small">SKU: <strong><?= e($product['sku']) ?></strong></span>
                    <?php if (!empty($product['model_number'])): ?>
                        <span class="text-muted small">&bull; Model: <strong><?= e($product['model_number']) ?></strong></span>
                    <?php endif; ?>
                </div>

                <h1 class="h2 fw-black text-dark mb-3"><?= e($product['name']) ?></h1>

                <!-- Price Block -->
                <div class="p-3 bg-light rounded-3 mb-4">
                    <div class="d-flex align-items-baseline gap-3">
                        <span class="display-6 fw-black text-primary"><?= formatTZS($product['price']) ?></span>
                        <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                            <span class="fs-5 text-muted text-decoration-line-through"><?= formatTZS($product['compare_at_price']) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="small text-muted mt-1">
                        Prices in Tanzanian Shillings (TZS). Inclusive of all applicable standard taxes.
                    </div>
                </div>

                <!-- Stock & Warranty Status -->
                <div class="row g-2 mb-4">
                    <div class="col-sm-6">
                        <div class="p-2 border rounded small d-flex align-items-center gap-2">
                            <?php if ($product['stock_quantity'] > 0): ?>
                                <i class="bi bi-check-circle-fill text-success fs-5"></i>
                                <div>
                                    <div class="fw-bold text-success">In Stock (<?= $product['stock_quantity'] ?> available)</div>
                                    <div class="text-muted" style="font-size: 0.75rem;">Ready for store pickup or delivery</div>
                                </div>
                            <?php else: ?>
                                <i class="bi bi-x-circle-fill text-danger fs-5"></i>
                                <div>
                                    <div class="fw-bold text-danger">Temporarily Out of Stock</div>
                                    <div class="text-muted" style="font-size: 0.75rem;">Contact on WhatsApp to backorder</div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="p-2 border rounded small d-flex align-items-center gap-2">
                            <i class="bi bi-shield-check text-primary fs-5"></i>
                            <div>
                                <div class="fw-bold"><?= e($product['warranty_info']) ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;">Official Store Warranty</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Short Description -->
                <p class="text-secondary mb-4 leading-relaxed"><?= nl2br(e($product['short_description'])) ?></p>

                <!-- Purchase Controls -->
                <div class="mt-auto pt-3 border-top">
                    <form action="<?= APP_URL ?>/cart/add" method="POST" class="mb-3">
                        <?= $csrfInput ?>
                        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                        <div class="row g-3 align-items-center">
                            <div class="col-4 col-sm-3">
                                <label class="form-label small fw-bold mb-1">Quantity:</label>
                                <input type="number" name="quantity" class="form-control form-control-lg text-center" value="1" min="1" max="<?= max(1, (int)$product['stock_quantity']) ?>" <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                            </div>
                            <div class="col-8 col-sm-9">
                                <label class="form-label small fw-bold mb-1 invisible">Action</label>
                                <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold shadow-sm" <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                    <i class="bi bi-cart-plus-fill me-2"></i> Add to Shopping Cart
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Direct WhatsApp Buy Button -->
                    <?php
                    $waOrderText = "Hello Pande Computers, I want to order this product directly:\n" .
                                   "Product: {$product['name']}\n" .
                                   "SKU: {$product['sku']}\n" .
                                   "Price: " . formatTZS($product['price']) . "\n" .
                                   "Please confirm availability and arrange payment/delivery.";
                    ?>
                    <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>?text=<?= rawurlencode($waOrderText) ?>" 
                       target="_blank" rel="noopener" 
                       class="btn btn-success btn-lg w-100 fw-bold shadow">
                        <i class="bi bi-whatsapp me-2"></i> Buy Instantly via WhatsApp (+255 787 311 342)
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Specifications & Full Description Tabs -->
    <div class="card border-0 shadow-sm rounded-3 mb-5">
        <div class="card-header bg-white border-bottom p-0">
            <ul class="nav nav-tabs border-0" id="productTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active fw-bold px-4 py-3 border-0 border-bottom border-primary border-3" id="desc-tab" data-bs-toggle="tab" data-bs-target="#desc-pane" type="button" role="tab">Full Description</button>
                </li>
                <?php if (!empty($product['specs_array'])): ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link fw-bold px-4 py-3 border-0" id="specs-tab" data-bs-toggle="tab" data-bs-target="#specs-pane" type="button" role="tab">Technical Specifications</button>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="card-body p-4">
            <div class="tab-content" id="productTabsContent">
                <div class="tab-pane fade show active leading-relaxed" id="desc-pane" role="tabpanel">
                    <?= nl2br(e($product['description'])) ?>
                </div>

                <?php if (!empty($product['specs_array'])): ?>
                    <div class="tab-pane fade" id="specs-pane" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped mb-0">
                                <tbody>
                                    <?php foreach ($product['specs_array'] as $key => $val): ?>
                                        <tr>
                                            <th class="bg-light text-secondary" style="width: 30%;"><?= e($key) ?></th>
                                            <td class="fw-semibold text-dark"><?= e((string)$val) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Related Products -->
    <?php if (!empty($relatedProducts)): ?>
        <div class="mb-5">
            <h3 class="fw-bold mb-4">Related Electronics & Similar Items</h3>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
                <?php foreach ($relatedProducts as $rel): ?>
                    <div class="col">
                        <div class="card product-card h-100 border-0 shadow-sm rounded-3 overflow-hidden">
                            <div class="card-body p-3 d-flex flex-column">
                                <span class="badge bg-light text-primary border align-self-start mb-2"><?= e($rel['brand']) ?></span>
                                <h6 class="card-title fw-bold mb-1">
                                    <a href="<?= APP_URL ?>/product/<?= e($rel['slug']) ?>" class="text-dark text-decoration-none hover-primary line-clamp-2">
                                        <?= e($rel['name']) ?>
                                    </a>
                                </h6>
                                <div class="mt-auto pt-2">
                                    <div class="fw-black text-primary fs-5 mb-2"><?= formatTZS($rel['price']) ?></div>
                                    <a href="<?= APP_URL ?>/product/<?= e($rel['slug']) ?>" class="btn btn-outline-dark btn-sm w-100 fw-semibold">View Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
