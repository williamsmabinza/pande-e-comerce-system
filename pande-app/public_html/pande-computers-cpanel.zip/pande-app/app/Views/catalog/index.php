<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/" class="text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= APP_URL ?>/shop" class="text-decoration-none">Shop</a></li>
            <?php if (!empty($selectedCategory)): ?>
                <li class="breadcrumb-item active" aria-current="page"><?= e($selectedCategory['name']) ?></li>
            <?php else: ?>
                <li class="breadcrumb-item active" aria-current="page">All Products</li>
            <?php endif; ?>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Sidebar Filters -->
        <aside class="col-lg-3">
            <div class="card border-0 shadow-sm rounded-3 p-3 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0 text-dark">Filters</h5>
                    <a href="<?= APP_URL ?>/shop" class="small text-danger text-decoration-none">Reset All</a>
                </div>

                <form action="<?= APP_URL ?>/shop" method="GET" id="filter-form">
                    <?php if (!empty($filters['query'])): ?>
                        <input type="hidden" name="q" value="<?= e($filters['query']) ?>">
                    <?php endif; ?>

                    <!-- Categories Filter -->
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-uppercase text-secondary">Categories</label>
                        <div class="category-filter-list" style="max-height: 250px; overflow-y: auto;">
                            <div class="form-check mb-1">
                                <input class="form-check-input" type="radio" name="category" id="cat-all" value="" <?= empty($filters['category_id']) ? 'checked' : '' ?> onchange="this.form.submit()">
                                <label class="form-check-label small" for="cat-all">All Categories</label>
                            </div>
                            <?php foreach ($allCategories as $c): ?>
                                <div class="form-check mb-1">
                                    <input class="form-check-input" type="radio" name="category" id="cat-<?= $c['id'] ?>" value="<?= $c['id'] ?>" <?= (!empty($filters['category_id']) && (int)$filters['category_id'] === (int)$c['id']) ? 'checked' : '' ?> onchange="this.form.submit()">
                                    <label class="form-check-label small text-truncate" for="cat-<?= $c['id'] ?>">
                                        <?= e($c['name']) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Price Range -->
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-uppercase text-secondary">Price Range (TZS)</label>
                        <div class="row g-2 mb-2">
                            <div class="col-6">
                                <input type="number" name="min_price" class="form-control form-control-sm" placeholder="Min" value="<?= e($filters['min_price'] ?? '') ?>">
                            </div>
                            <div class="col-6">
                                <input type="number" name="max_price" class="form-control form-control-sm" placeholder="Max" value="<?= e($filters['max_price'] ?? '') ?>">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-dark btn-sm w-100">Apply Price Filter</button>
                    </div>

                    <!-- Availability -->
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-uppercase text-secondary">Availability</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="in_stock" value="1" id="in-stock" <?= !empty($filters['in_stock']) ? 'checked' : '' ?> onchange="this.form.submit()">
                            <label class="form-check-label small" for="in-stock">In Stock Only</label>
                        </div>
                    </div>

                    <!-- Sorting hidden if set -->
                    <input type="hidden" name="sort" value="<?= e($filters['sort'] ?? 'newest') ?>">
                </form>
            </div>

            <!-- Kariakoo Store Notice -->
            <div class="p-3 bg-navy text-white rounded-3 small">
                <div class="fw-bold mb-1"><i class="bi bi-geo-alt-fill text-warning me-1"></i> Visit Store in Person</div>
                <p class="text-white-50 mb-2">Ndanda & Aggrey Street, Kariakoo, Dar es Salaam. Test devices and pick up in store.</p>
                <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>" target="_blank" rel="noopener" class="text-info fw-bold text-decoration-none">
                    <i class="bi bi-whatsapp"></i> Chat on WhatsApp &rarr;
                </a>
            </div>
        </aside>

        <!-- Product Listing Grid -->
        <main class="col-lg-9">
            <!-- Header bar with Title, Count, Sort -->
            <div class="card border-0 shadow-sm rounded-3 p-3 mb-4">
                <div class="row align-items-center gy-2">
                    <div class="col-sm-6">
                        <h4 class="fw-bold mb-0 text-dark">
                            <?= !empty($selectedCategory) ? e($selectedCategory['name']) : (!empty($filters['query']) ? 'Search: "' . e($filters['query']) . '"' : 'All Products') ?>
                        </h4>
                        <span class="small text-muted">Showing <?= count($products) ?> of <?= $total ?> products found</span>
                    </div>
                    <div class="col-sm-6 text-sm-end">
                        <div class="d-inline-flex align-items-center gap-2">
                            <label class="small text-muted text-nowrap">Sort By:</label>
                            <select class="form-select form-select-sm" style="width: 170px;" onchange="location = this.value;">
                                <?php
                                $currentUrl = APP_URL . '/shop?' . http_build_query(array_merge($filters, ['page' => 1]));
                                ?>
                                <option value="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['sort' => 'newest', 'page' => 1])) ?>" <?= ($filters['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Newest First</option>
                                <option value="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['sort' => 'price_asc', 'page' => 1])) ?>" <?= ($filters['sort'] ?? '') === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                                <option value="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['sort' => 'price_desc', 'page' => 1])) ?>" <?= ($filters['sort'] ?? '') === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                                <option value="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['sort' => 'name_asc', 'page' => 1])) ?>" <?= ($filters['sort'] ?? '') === 'name_asc' ? 'selected' : '' ?>>Product Name (A-Z)</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Products Grid -->
            <?php if (empty($products)): ?>
                <div class="card border-0 shadow-sm rounded-3 p-5 text-center my-4">
                    <i class="bi bi-search text-muted mb-3" style="font-size: 3.5rem;"></i>
                    <h5 class="fw-bold">No Products Found</h5>
                    <p class="text-muted small mb-4">We couldn't find any electronics matching your criteria. Try adjusting your filters or search keywords.</p>
                    <div>
                        <a href="<?= APP_URL ?>/shop" class="btn btn-primary px-4 fw-semibold">View All Products</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
                    <?php foreach ($products as $product): ?>
                        <div class="col">
                            <div class="card product-card h-100 border-0 shadow-sm rounded-3 overflow-hidden position-relative">
                                <!-- Badges -->
                                <div class="position-absolute top-0 start-0 m-2 d-flex flex-column gap-1 z-2">
                                    <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                                        <?php $discount = round((($product['compare_at_price'] - $product['price']) / $product['compare_at_price']) * 100); ?>
                                        <span class="badge bg-danger shadow-sm">-<?= $discount ?>%</span>
                                    <?php endif; ?>
                                    <span class="badge bg-navy text-white shadow-sm"><?= e($product['brand']) ?></span>
                                </div>

                                <!-- Image / Icon -->
                                <a href="<?= APP_URL ?>/product/<?= e($product['slug']) ?>" class="product-thumb-container d-block bg-white text-center p-3 border-bottom text-decoration-none">
                                    <div class="product-img-wrapper d-flex align-items-center justify-content-center" style="height: 170px;">
                                        <i class="bi bi-cpu text-primary opacity-75" style="font-size: 4.5rem;"></i>
                                    </div>
                                </a>

                                <!-- Body -->
                                <div class="card-body p-3 d-flex flex-column">
                                    <div class="small text-muted mb-1"><?= e($product['category_name']) ?></div>
                                    <h6 class="card-title fw-bold mb-2">
                                        <a href="<?= APP_URL ?>/product/<?= e($product['slug']) ?>" class="text-dark text-decoration-none hover-primary line-clamp-2">
                                            <?= e($product['name']) ?>
                                        </a>
                                    </h6>

                                    <div class="mt-auto pt-2">
                                        <div class="d-flex align-items-baseline gap-2 mb-2">
                                            <span class="fw-black text-primary fs-5"><?= formatTZS($product['price']) ?></span>
                                            <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                                                <span class="text-muted small text-decoration-line-through"><?= formatTZS($product['compare_at_price']) ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="d-flex align-items-center justify-content-between small text-muted mb-3">
                                            <?php if ($product['stock_quantity'] > 0): ?>
                                                <span class="text-success fw-semibold"><i class="bi bi-check-circle me-1"></i> In Stock (<?= $product['stock_quantity'] ?>)</span>
                                            <?php else: ?>
                                                <span class="text-danger fw-semibold"><i class="bi bi-x-circle me-1"></i> Out of Stock</span>
                                            <?php endif; ?>
                                            <span>SKU: <?= e($product['sku']) ?></span>
                                        </div>

                                        <div class="row g-2">
                                            <div class="col-8">
                                                <form action="<?= APP_URL ?>/cart/add" method="POST" class="add-to-cart-form">
                                                    <?= $csrfInput ?>
                                                    <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="btn btn-primary w-100 fw-semibold btn-sm py-2" <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                                        <i class="bi bi-cart-plus me-1"></i> Add to Cart
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="col-4">
                                                <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>?text=<?= rawurlencode("Hello Pande Computers, I want to order: {$product['name']} (SKU: {$product['sku']}) for " . formatTZS($product['price'])) ?>" 
                                                   target="_blank" rel="noopener" class="btn btn-success w-100 btn-sm py-2" title="Order via WhatsApp">
                                                    <i class="bi bi-whatsapp"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-5" aria-label="Catalog pagination">
                        <ul class="pagination justify-content-center">
                            <?php if ($currentPage > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['page' => $currentPage - 1])) ?>">Previous</a>
                                </li>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['page' => $i])) ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($currentPage < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= APP_URL ?>/shop?<?= http_build_query(array_merge($filters, ['page' => $currentPage + 1])) ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
</div>
