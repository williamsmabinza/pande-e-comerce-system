<!-- Hero Section -->
<section class="hero-banner py-5 bg-navy text-white position-relative overflow-hidden">
    <div class="container position-relative z-1 py-4">
        <div class="row align-items-center gy-4">
            <div class="col-lg-7">
                <span class="badge bg-warning text-dark text-uppercase fw-bold px-3 py-2 mb-3 shadow-sm">
                    <i class="bi bi-shield-check me-1"></i> Authorized Technology Retailer &bull; Kariakoo, DSM
                </span>
                <h1 class="display-4 fw-black text-white mb-3 tracking-tight">
                    UNCOMPROMISED POWER.<br>
                    <span class="text-primary-light text-gradient">UNBEATABLE PRICES.</span>
                </h1>
                <p class="lead text-white-50 mb-4 pe-lg-4">
                    Tanzania's premier destination for genuine business laptops, desktop PCs, displays, high-speed networking, printers, components, and power backup solutions.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= APP_URL ?>/shop" class="btn btn-primary btn-lg px-4 fw-bold shadow">
                        <i class="bi bi-grid-fill me-2"></i> Browse Tech Catalog
                    </a>
                    <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>" target="_blank" rel="noopener" class="btn btn-outline-light btn-lg px-4 fw-semibold">
                        <i class="bi bi-whatsapp text-success me-2"></i> Order via WhatsApp
                    </a>
                </div>
                <div class="d-flex align-items-center gap-4 mt-4 pt-3 border-top border-secondary border-opacity-25 small text-white-50">
                    <div><i class="bi bi-check-circle-fill text-success me-1"></i> 100% Genuine Products</div>
                    <div><i class="bi bi-check-circle-fill text-success me-1"></i> Warranty Support</div>
                    <div><i class="bi bi-check-circle-fill text-success me-1"></i> Same-Day Delivery in DSM</div>
                </div>
            </div>
            <div class="col-lg-5 text-center">
                <div class="hero-card bg-white bg-opacity-10 p-4 rounded-4 shadow-lg border border-white border-opacity-10 backdrop-blur">
                    <div class="p-3 bg-white rounded-3 shadow-sm mb-3 text-dark text-start">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge bg-danger">SPECIAL OFFER</span>
                            <span class="small text-muted">SKU: LAP-HP-840G8</span>
                        </div>
                        <h5 class="fw-bold mb-1">HP EliteBook 840 G8</h5>
                        <p class="small text-muted mb-2">Intel Core i7 &bull; 16GB RAM &bull; 512GB SSD</p>
                        <div class="d-flex align-items-baseline gap-2">
                            <span class="fs-4 fw-black text-primary">TZS 1,850,000</span>
                            <span class="small text-decoration-line-through text-muted">TZS 2,100,000</span>
                        </div>
                    </div>
                    <div class="row g-2 text-start text-white small">
                        <div class="col-6">
                            <div class="p-2 rounded bg-dark bg-opacity-50">
                                <i class="bi bi-geo-alt text-warning"></i> Kariakoo Store Pickup
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 rounded bg-dark bg-opacity-50">
                                <i class="bi bi-truck text-info"></i> Upcountry Delivery
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Popular Categories Section -->
<section class="py-5 bg-white border-bottom">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <h6 class="text-primary fw-bold text-uppercase small tracking-wide mb-1">Explore By Category</h6>
                <h2 class="fw-bold mb-0 text-dark">Top Technology Departments</h2>
            </div>
            <a href="<?= APP_URL ?>/shop" class="btn btn-outline-dark btn-sm fw-semibold">
                All 20 Categories <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>

        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-6 g-3">
            <?php foreach ($popularCategories as $cat): ?>
                <div class="col">
                    <a href="<?= APP_URL ?>/category/<?= e($cat['slug']) ?>" class="category-card card h-100 text-decoration-none border shadow-sm text-center p-3 hover-lift">
                        <div class="category-icon mx-auto mb-2 rounded-circle bg-primary-subtle text-primary d-flex align-items-center justify-content-center">
                            <i class="bi <?= e($cat['icon_class'] ?: 'bi-cpu') ?> fs-3"></i>
                        </div>
                        <h6 class="card-title fw-bold text-dark small mb-1"><?= e($cat['name']) ?></h6>
                        <span class="text-muted" style="font-size: 0.75rem;"><?= (int)($cat['product_count'] ?? 0) ?> items</span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products Section -->
<section class="py-5 bg-body-tertiary">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <span class="badge bg-primary text-uppercase px-2 py-1 mb-1">Handpicked & Verified</span>
                <h2 class="fw-bold mb-0 text-dark">Featured Electronics & Computers</h2>
            </div>
            <a href="<?= APP_URL ?>/shop" class="btn btn-link text-decoration-none fw-semibold">
                View Full Shop <i class="bi bi-arrow-right"></i>
            </a>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($featuredProducts as $product): ?>
                <div class="col">
                    <div class="card product-card h-100 border-0 shadow-sm rounded-3 overflow-hidden position-relative">
                        <!-- Product Badges -->
                        <div class="position-absolute top-0 start-0 m-2 d-flex flex-column gap-1 z-2">
                            <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                                <?php $discount = round((($product['compare_at_price'] - $product['price']) / $product['compare_at_price']) * 100); ?>
                                <span class="badge bg-danger shadow-sm">-<?= $discount ?>%</span>
                            <?php endif; ?>
                            <span class="badge bg-navy text-white shadow-sm"><?= e($product['brand']) ?></span>
                        </div>

                        <!-- Product Thumbnail -->
                        <a href="<?= APP_URL ?>/product/<?= e($product['slug']) ?>" class="product-thumb-container d-block bg-white text-center p-3 border-bottom text-decoration-none">
                            <div class="product-img-wrapper d-flex align-items-center justify-content-center" style="height: 180px;">
                                <i class="bi bi-laptop text-primary opacity-75" style="font-size: 5rem;"></i>
                            </div>
                        </a>

                        <!-- Card Body -->
                        <div class="card-body p-3 d-flex flex-column">
                            <div class="small text-muted mb-1"><?= e($product['category_name']) ?></div>
                            <h6 class="card-title fw-bold mb-2">
                                <a href="<?= APP_URL ?>/product/<?= e($product['slug']) ?>" class="text-dark text-decoration-none hover-primary line-clamp-2">
                                    <?= e($product['name']) ?>
                                </a>
                            </h6>

                            <div class="mt-auto pt-2">
                                <div class="d-flex align-items-baseline gap-2 mb-2">
                                    <span class="fw-black text-primary fs-5"><?= formatTZS($product['price']) ?></span>
                                    <?php if (!empty($product['compare_at_price']) && $product['compare_at_price'] > $product['price']): ?>
                                        <span class="text-muted small text-decoration-line-through"><?= formatTZS($product['compare_at_price']) ?></span>
                                    <?php endif; ?>
                                </div>

                                <div class="d-flex align-items-center justify-content-between small text-muted mb-3">
                                    <?php if ($product['stock_quantity'] > 0): ?>
                                        <span class="text-success fw-semibold"><i class="bi bi-check-circle me-1"></i> In Stock (<?= $product['stock_quantity'] ?>)</span>
                                    <?php else: ?>
                                        <span class="text-danger fw-semibold"><i class="bi bi-x-circle me-1"></i> Out of Stock</span>
                                    <?php endif; ?>
                                    <span><?= e($product['warranty_info']) ?></span>
                                </div>

                                <div class="row g-2">
                                    <div class="col-8">
                                        <form action="<?= APP_URL ?>/cart/add" method="POST" class="add-to-cart-form">
                                            <?= $csrfInput ?>
                                            <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="btn btn-primary w-100 fw-semibold btn-sm py-2" <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                                <i class="bi bi-cart-plus me-1"></i> Add to Cart
                                            </button>
                                        </form>
                                    </div>
                                    <div class="col-4">
                                        <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>?text=<?= rawurlencode("Hello Pande Computers, I am interested in: {$product['name']} (SKU: {$product['sku']}) priced at " . formatTZS($product['price'])) ?>" 
                                           target="_blank" rel="noopener" class="btn btn-success w-100 btn-sm py-2" title="Ask on WhatsApp">
                                            <i class="bi bi-whatsapp"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- New Arrivals Banner -->
<section class="py-5 bg-white border-top">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <span class="badge bg-success text-uppercase px-2 py-1 mb-1">Just Landed</span>
                <h2 class="fw-bold mb-0 text-dark">Latest Arrivals in Dar es Salaam</h2>
            </div>
            <a href="<?= APP_URL ?>/shop" class="btn btn-link text-decoration-none fw-semibold">
                Explore All Products <i class="bi bi-arrow-right"></i>
            </a>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($newArrivals as $product): ?>
                <div class="col">
                    <div class="card product-card h-100 border shadow-sm rounded-3 overflow-hidden position-relative">
                        <div class="card-body p-3 d-flex flex-column">
                            <span class="badge bg-light text-primary border align-self-start mb-2"><?= e($product['brand']) ?></span>
                            <h6 class="card-title fw-bold mb-1">
                                <a href="<?= APP_URL ?>/product/<?= e($product['slug']) ?>" class="text-dark text-decoration-none hover-primary">
                                    <?= e($product['name']) ?>
                                </a>
                            </h6>
                            <p class="small text-muted line-clamp-2 mb-3"><?= e($product['short_description']) ?></p>

                            <div class="mt-auto">
                                <div class="fw-black text-primary fs-5 mb-2"><?= formatTZS($product['price']) ?></div>
                                <form action="<?= APP_URL ?>/cart/add" method="POST">
                                    <?= $csrfInput ?>
                                    <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                                    <button type="submit" class="btn btn-outline-primary w-100 btn-sm fw-semibold" <?= $product['stock_quantity'] <= 0 ? 'disabled' : '' ?>>
                                        <i class="bi bi-cart-plus me-1"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Trust & Why Shop With Us -->
<section class="py-5 bg-navy text-white">
    <div class="container py-3">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6">
                <div class="p-3">
                    <div class="feature-icon mb-3 text-warning fs-1"><i class="bi bi-patch-check-fill"></i></div>
                    <h5 class="fw-bold text-white mb-2">100% Genuine Tech</h5>
                    <p class="small text-white-50 mb-0">Original laptops, components, and electronics directly from authorized distributors.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3">
                    <div class="feature-icon mb-3 text-success fs-1"><i class="bi bi-whatsapp"></i></div>
                    <h5 class="fw-bold text-white mb-2">Instant WhatsApp Checkout</h5>
                    <p class="small text-white-50 mb-0">Fast, personal order confirmation and real-time support from our Kariakoo team.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3">
                    <div class="feature-icon mb-3 text-info fs-1"><i class="bi bi-truck"></i></div>
                    <h5 class="fw-bold text-white mb-2">Nationwide Shipping</h5>
                    <p class="small text-white-50 mb-0">Fast deliveries across Dar es Salaam, Arusha, Mwanza, Dodoma, and all Tanzania regions.</p>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="p-3">
                    <div class="feature-icon mb-3 text-primary-light fs-1"><i class="bi bi-shield-lock-fill"></i></div>
                    <h5 class="fw-bold text-white mb-2">Warranty Backed</h5>
                    <p class="small text-white-50 mb-0">Transparent warranties on every device with dedicated technician support.</p>
                </div>
            </div>
        </div>
    </div>
</section>
