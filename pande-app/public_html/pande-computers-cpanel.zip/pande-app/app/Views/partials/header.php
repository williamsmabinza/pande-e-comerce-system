<!-- Top Info Announcement Bar -->
<div class="top-bar bg-dark text-white py-1-5 border-bottom border-secondary border-opacity-25 small">
    <div class="container d-flex flex-wrap justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-3">
            <span><i class="bi bi-geo-alt-fill text-primary me-1"></i> <?= e($storeLocation ?? 'Ndanda & Aggrey Street, Kariakoo, Dar es Salaam') ?></span>
            <span class="d-none d-md-inline text-secondary">|</span>
            <span class="d-none d-md-inline"><i class="bi bi-telephone-fill text-primary me-1"></i> <?= e($storePhone ?? '+255 787 311 342') ?></span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <a href="https://wa.me/<?= e($storeWhatsApp ?? '255787311342') ?>" target="_blank" rel="noopener" class="text-white text-decoration-none fw-semibold">
                <i class="bi bi-whatsapp text-success me-1"></i> Order on WhatsApp: +255 787 311 342
            </a>
            <?php if (!empty($isAdmin) || !empty($isStaff)): ?>
                <span class="text-secondary">|</span>
                <a href="<?= APP_URL ?>/admin" class="badge bg-primary text-decoration-none"><i class="bi bi-speedometer2 me-1"></i> Admin Portal</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Main Header -->
<header class="main-header bg-white sticky-top shadow-sm py-2">
    <div class="container">
        <div class="row align-items-center gy-2">
            <!-- Brand Logo -->
            <div class="col-6 col-lg-3">
                <a href="<?= APP_URL ?>/" class="d-inline-flex align-items-center text-decoration-none">
                    <img src="<?= asset('assets/images/logo-horizontal.svg') ?>" alt="Pande Computers" height="48" class="img-fluid logo-img">
                </a>
            </div>

            <!-- Global Search Form -->
            <div class="col-12 col-lg-6 order-3 order-lg-2">
                <form action="<?= APP_URL ?>/shop" method="GET" class="search-form">
                    <div class="input-group">
                        <input type="text" name="q" class="form-control form-control-lg border-2 border-primary-subtle" 
                               placeholder="Search laptops, monitors, printers, components..." 
                               value="<?= e($_GET['q'] ?? '') ?>" aria-label="Search products">
                        <button class="btn btn-primary px-4 fw-semibold" type="submit">
                            <i class="bi bi-search me-1"></i> <span class="d-none d-sm-inline">Search</span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- User and Cart Actions -->
            <div class="col-6 col-lg-3 order-2 order-lg-3 text-end d-flex justify-content-end align-items-center gap-2">
                <!-- Customer Account -->
                <div class="dropdown">
                    <button class="btn btn-outline-dark dropdown-toggle d-flex align-items-center gap-2 py-2" type="button" data-bs-dismiss="dropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle fs-5"></i>
                        <span class="d-none d-xl-inline text-truncate" style="max-width: 120px;">
                            <?= !empty($isAuthenticated) ? e($currentUser['first_name']) : 'Account' ?>
                        </span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
                        <?php if (!empty($isAuthenticated)): ?>
                            <li class="px-3 py-2 border-bottom">
                                <div class="fw-bold"><?= e($currentUser['first_name'] . ' ' . $currentUser['last_name']) ?></div>
                                <div class="small text-muted"><?= e($currentUser['email']) ?></div>
                            </li>
                            <?php if (!empty($isAdmin) || !empty($isStaff)): ?>
                                <li><a class="dropdown-item py-2 text-primary fw-semibold" href="<?= APP_URL ?>/admin"><i class="bi bi-speedometer2 me-2"></i> Admin Panel</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item py-2" href="<?= APP_URL ?>/customer/dashboard"><i class="bi bi-grid me-2"></i> My Dashboard</a></li>
                            <li><a class="dropdown-item py-2" href="<?= APP_URL ?>/customer/orders"><i class="bi bi-box-seam me-2"></i> My Orders</a></li>
                            <li><a class="dropdown-item py-2" href="<?= APP_URL ?>/customer/profile"><i class="bi bi-person-gear me-2"></i> Edit Profile</a></li>
                            <li><a class="dropdown-item py-2" href="<?= APP_URL ?>/customer/addresses"><i class="bi bi-geo-alt me-2"></i> My Addresses</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="<?= APP_URL ?>/logout" method="POST">
                                    <?= $csrfInput ?>
                                    <button type="submit" class="dropdown-item py-2 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Sign Out</button>
                                </form>
                            </li>
                        <?php else: ?>
                            <li><a class="dropdown-item py-2 fw-semibold" href="<?= APP_URL ?>/login"><i class="bi bi-box-arrow-in-right me-2"></i> Sign In</a></li>
                            <li><a class="dropdown-item py-2" href="<?= APP_URL ?>/register"><i class="bi bi-person-plus me-2"></i> Create Customer Account</a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Shopping Cart -->
                <a href="<?= APP_URL ?>/cart" class="btn btn-primary d-flex align-items-center gap-2 py-2 position-relative text-white">
                    <i class="bi bi-cart3 fs-5"></i>
                    <span class="d-none d-sm-inline fw-semibold">Cart</span>
                    <span class="badge bg-danger rounded-pill cart-count-badge">
                        <?= (int)($cartTotals['count'] ?? 0) ?>
                    </span>
                </a>
            </div>
        </div>
    </div>

    <!-- Category Bar -->
    <nav class="category-nav border-top mt-2 pt-2 bg-light-subtle d-none d-md-block">
        <div class="container d-flex align-items-center justify-content-between overflow-x-auto py-1">
            <div class="d-flex align-items-center gap-1 flex-nowrap">
                <!-- All Categories Dropdown -->
                <div class="dropdown me-2">
                    <button class="btn btn-navy text-white dropdown-toggle btn-sm fw-bold px-3 py-1-5" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-list me-1"></i> All Categories
                    </button>
                    <ul class="dropdown-menu shadow-lg border-0 py-2" style="max-height: 400px; overflow-y: auto; width: 280px;">
                        <?php foreach ($allCategories as $cat): ?>
                            <li>
                                <a class="dropdown-item py-2 d-flex justify-content-between align-items-center" href="<?= APP_URL ?>/category/<?= e($cat['slug']) ?>">
                                    <span><i class="bi <?= e($cat['icon_class'] ?: 'bi-chevron-right') ?> me-2 text-primary"></i> <?= e($cat['name']) ?></span>
                                    <span class="badge bg-light text-dark rounded-pill"><?= (int)($cat['product_count'] ?? 0) ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Featured Quick Links -->
                <a href="<?= APP_URL ?>/shop" class="nav-link px-2 fw-semibold text-dark">All Products</a>
                <?php foreach ($headerCategories as $hcat): ?>
                    <a href="<?= APP_URL ?>/category/<?= e($hcat['slug']) ?>" class="nav-link px-2 text-dark small text-nowrap">
                        <?= e($hcat['name']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
            <div class="d-flex align-items-center gap-3">
                <a href="<?= APP_URL ?>/about" class="small text-muted text-decoration-none">About Us</a>
                <a href="<?= APP_URL ?>/contact" class="small text-muted text-decoration-none">Contact & Location</a>
            </div>
        </div>
    </nav>
</header>
