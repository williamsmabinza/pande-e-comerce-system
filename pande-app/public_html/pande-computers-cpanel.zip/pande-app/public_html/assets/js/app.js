// Pande Computers - Interactive Frontend App JS
document.addEventListener('DOMContentLoaded', function() {
    // Dynamic AJAX Add to Cart
    document.querySelectorAll('.add-to-cart-form').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            // Optional AJAX progressive enhancement
            // Allows normal submit or instant update if fetch works
            const formData = new FormData(form);
            const btn = form.querySelector('button[type="submit"]');
            const originalHtml = btn.innerHTML;

            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Adding...';
            btn.disabled = true;

            fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(res => {
                if (!res.ok) throw new Error('Network error');
                return res.json();
            })
            .then(data => {
                if (data.success) {
                    btn.innerHTML = '<i class="bi bi-check-lg me-1"></i> Added!';
                    btn.classList.remove('btn-primary');
                    btn.classList.add('btn-success');

                    // Update header cart badge
                    document.querySelectorAll('.cart-count-badge').forEach(badge => {
                        badge.textContent = data.count;
                    });

                    setTimeout(() => {
                        btn.innerHTML = originalHtml;
                        btn.classList.remove('btn-success');
                        btn.classList.add('btn-primary');
                        btn.disabled = false;
                    }, 1500);
                } else {
                    form.submit(); // fallback to standard submit
                }
            })
            .catch(() => {
                // If anything fails or not JSON, fall back to native submission
                form.submit();
            });

            e.preventDefault();
        });
    });
});
