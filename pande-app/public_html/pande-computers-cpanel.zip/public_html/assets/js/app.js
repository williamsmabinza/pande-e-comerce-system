// ============================================================================
// PANDE COMPUTERS - INTERACTIVE FRONTEND APPLICATION JS
// High-Trust E-Commerce Shopping Experience
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    initAddToCart();
    initCartToastContainer();
});

// Toast notification container element
let toastContainer = null;

function initCartToastContainer() {
    if (!document.querySelector('.cart-toast-container')) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'cart-toast-container';
        toastContainer.setAttribute('aria-live', 'polite');
        document.body.appendChild(toastContainer);
    } else {
        toastContainer = document.querySelector('.cart-toast-container');
    }
}

/**
 * Display interactive floating toast notification when product is added
 */
function showCartToast(data) {
    if (!toastContainer) {
        initCartToastContainer();
    }

    const toast = document.createElement('div');
    toast.className = 'cart-toast shadow-lg';
    
    const productName = data.product_name || 'Selected Item';
    const productPrice = data.product_price || '';
    const productImage = data.product_image || '/assets/images/products/laptop.svg';
    const subtotal = data.subtotal || '';
    const count = data.count || 1;

    toast.innerHTML = `
        <div class="d-flex align-items-start gap-3">
            <div class="border rounded p-1 bg-light text-center flex-shrink-0" style="width: 52px; height: 52px; display: flex; align-items: center; justify-content: center;">
                <img src="${productImage}" alt="${productName}" style="max-width: 44px; max-height: 44px; object-fit: contain;">
            </div>
            <div class="flex-grow-1" style="min-width: 0;">
                <div class="d-flex align-items-center justify-content-between mb-1">
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-0.5" style="font-size: 0.72rem;">
                        <i class="bi bi-check2-circle me-1"></i> Added to Cart
                    </span>
                    <button type="button" class="btn-close btn-close-sm p-1" style="font-size: 0.65rem;" aria-label="Close"></button>
                </div>
                <div class="fw-bold text-dark small text-truncate mb-1" title="${productName}">
                    ${productName}
                </div>
                <div class="small text-muted" style="font-size: 0.75rem;">
                    ${productPrice ? `<span class="fw-semibold text-dark">${productPrice}</span> &bull; ` : ''}
                    Cart: <strong>${count} ${count === 1 ? 'item' : 'items'}</strong> (${subtotal})
                </div>
            </div>
        </div>
        <div class="d-flex gap-2 mt-3 pt-2 border-top">
            <a href="/cart" class="btn btn-primary btn-sm fw-bold flex-grow-1 text-center py-1.5" style="font-size: 0.8rem;">
                <i class="bi bi-bag-check me-1"></i> View Cart &amp; Checkout &rarr;
            </a>
            <button type="button" class="btn btn-outline-secondary btn-sm toast-dismiss-btn px-2.5 py-1.5" style="font-size: 0.8rem;">
                Continue
            </button>
        </div>
    `;

    // Dismiss handlers
    const dismissToast = () => {
        toast.classList.add('toast-hiding');
        setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.btn-close').addEventListener('click', dismissToast);
    toast.querySelector('.toast-dismiss-btn').addEventListener('click', dismissToast);

    // Auto dismiss after 5 seconds
    const autoTimer = setTimeout(dismissToast, 5000);
    toast.addEventListener('mouseenter', () => clearTimeout(autoTimer));

    toastContainer.appendChild(toast);
}

/**
 * Display error toast if cart operation fails (e.g. out of stock)
 */
function showErrorToast(message) {
    if (!toastContainer) {
        initCartToastContainer();
    }

    const toast = document.createElement('div');
    toast.className = 'cart-toast border-danger-subtle shadow-lg';
    toast.innerHTML = `
        <div class="d-flex align-items-center gap-2">
            <i class="bi bi-exclamation-circle-fill text-danger fs-5"></i>
            <div class="flex-grow-1 small fw-semibold text-dark">
                ${message || 'Unable to update cart. Please try again.'}
            </div>
            <button type="button" class="btn-close btn-close-sm" aria-label="Close"></button>
        </div>
    `;

    const dismissToast = () => {
        toast.classList.add('toast-hiding');
        setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.btn-close').addEventListener('click', dismissToast);
    setTimeout(dismissToast, 4500);
    toastContainer.appendChild(toast);
}

/**
 * Handle Add to Cart submission dynamically across all product cards and views
 */
function initAddToCart() {
    // Event delegation on document ensures dynamically rendered forms or detail pages are always caught
    document.addEventListener('submit', function(e) {
        const form = e.target;
        if (!form || !form.classList.contains('add-to-cart-form')) {
            return;
        }

        e.preventDefault();

        const btn = form.querySelector('button[type="submit"]');
        if (!btn || btn.disabled) {
            return;
        }

        const originalHtml = btn.innerHTML;
        const originalWidth = btn.offsetWidth ? `${btn.offsetWidth}px` : 'auto';

        // Set visual loading state
        btn.style.minWidth = originalWidth;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span> Adding...';
        btn.disabled = true;

        const formData = new FormData(form);
        const actionUrl = form.action || '/cart/add';

        fetch(actionUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => {
            return res.json().then(data => ({
                status: res.status,
                ok: res.ok,
                data: data
            })).catch(() => ({
                status: res.status,
                ok: res.ok,
                data: null
            }));
        })
        .then(result => {
            if (result.ok && result.data && result.data.success) {
                const data = result.data;

                // Button visual feedback: green checkmark
                btn.innerHTML = '<i class="bi bi-check2 me-1"></i> Added!';
                btn.classList.remove('btn-primary', 'btn-outline-primary');
                btn.classList.add('btn-success');

                // 1. Update all header cart count badges
                document.querySelectorAll('.cart-count-badge').forEach(badge => {
                    badge.textContent = data.count;
                    badge.classList.remove('cart-bump');
                    void badge.offsetWidth; // trigger reflow
                    badge.classList.add('cart-bump');
                });

                // 2. Update header cart subtotal
                if (data.subtotal) {
                    document.querySelectorAll('.header-cart-subtotal').forEach(el => {
                        el.textContent = data.subtotal;
                    });
                }

                // 3. Header cart icon wiggle
                document.querySelectorAll('.header-cart-icon').forEach(icon => {
                    icon.classList.remove('cart-bump');
                    void icon.offsetWidth;
                    icon.classList.add('cart-bump');
                });

                // 4. Show prominent floating cart confirmation toast
                showCartToast(data);

                // Reset button state smoothly after 2 seconds
                setTimeout(() => {
                    btn.innerHTML = originalHtml;
                    btn.classList.remove('btn-success');
                    btn.classList.add('btn-primary');
                    btn.disabled = false;
                }, 2000);
            } else {
                // Server rejected (e.g. out of stock or error)
                const errorMsg = (result.data && result.data.message) ? result.data.message : 'Item could not be added.';
                showErrorToast(errorMsg);
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            }
        })
        .catch(err => {
            console.error('[Add to Cart Error]', err);
            // Re-enable button and submit natively if fetch network error occurred
            btn.innerHTML = originalHtml;
            btn.disabled = false;
            form.submit();
        });
    });
}
